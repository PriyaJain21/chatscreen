import 'package:flutter/material.dart';

class ChatPge extends StatelessWidget {
  const ChatPge({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Stack(
            children: [
              Positioned(
                child: Container(
                  height: 250,
                  color: Color(0xfffef2fa),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(left: 25, right: 25, top: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundImage: NetworkImage(
                            "https://tse4.mm.bing.net/th?id=OIP.lWIF0fxWlXdL4y3H-9-XOAHaJ4&pid=Api&P=0",
                          ),
                        ),
                        Text(
                          "Puzzels",
                          style: TextStyle(
                            color: Colors.pinkAccent,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Icon(Icons.filter)
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                child: Container(
                  margin: EdgeInsets.only(top: 20, left: 25, right: 25),
                  height: 200,
                  child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: 8,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Container(
                              margin:
                                  EdgeInsets.only(left: 10, right: 10, top: 70),
                              height: 100,
                              width: 80,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: NetworkImage(
                                      "https://tse1.mm.bing.net/th?id=OIP.KU6oNv_eed8I00KJRz2mYwHaIE&pid=Api&P=0",
                                    ),
                                    fit: BoxFit.cover),
                              ),
                            )
                          ],
                        );
                      }),
                ),
              ),
              Positioned(child: Center(
                child: Container(
                  margin: EdgeInsets.only(top: 200,),
                  height: 30,
                  width: 200,
                  color: Colors.white70,

                  child: TextFormField(
                    cursorColor: Colors.black,
                    cursorHeight: 15,
                    textAlign: TextAlign.start,
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.search)
                    ),
                  ),
                ),
              )),
              Positioned(
                  child: Container(
                margin: EdgeInsets.only(top: 230),
                //color: Colors.red,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                    )),
                height: 525,
                child: ListView.builder(
                  padding: EdgeInsets.only(top: 30),
                    scrollDirection: Axis.vertical,
                    itemCount: 10,
                    itemBuilder: (context, item) {
                      return Card(
                        child: ListTile(
                          onTap: () {},
                          leading: CircleAvatar(
                            backgroundImage:  NetworkImage(
                                "https://tse1.mm.bing.net/th?id=OIP.KU6oNv_eed8I00KJRz2mYwHaIE&pid=Api&P=0",
                              ),
                          ),
                          title: Row(
                            children: [
                              Text("Jorden", style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87
                              ),),
                              SizedBox(width: 5,),
                              Icon(Icons.check_circle,color: Colors.deepPurpleAccent,size: 15,)
                            ],
                          ),
                          subtitle: Text("Hii!", style: TextStyle(
                              fontSize: 13,
                              color: Colors.black54
                          ),),
                          trailing: Column(
                            children: [
                              Text("13:30",style: TextStyle(fontSize: 13),),
                              Icon(Icons.arrow_circle_right_sharp,color: Colors.pinkAccent,size: 15,)
                            ],
                          ),
                        ),
                      );
                    }),
              ))
            ],
          )
        ],
      ),
    );
  }
}
